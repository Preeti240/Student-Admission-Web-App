from django.apps import AppConfig


class RegConfig(AppConfig):
    name = 'reg'
